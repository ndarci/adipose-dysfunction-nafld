# Co-localization analysis pipeline
* Data: 
* KOBS baseline adipose (bulk RNA-seq)
* imputed METSIM 10k genotype data

# Install PLINK v1.9
```{bash}
cd bin/scripts/
./installPLINK.sh
```

# Filter raw SNP data
* Remove SNPs with MAF<5%
* Remove SNPs with p<1e-6 after HWE test
```{bash}
./runPLINKfilterSNPs.sh
```

# Run cis-eQTL analysis
Format the data how we want it
* Rename columns (samples) to match between SNP and expression files
* Crop SNP file to have just one column before the samples start (SNP ID)
* Create files containing positions of SNPs and genes, remove ENSEMBL version on gene IDs, and put all chromosome IDs in "chr1" form
```{bash}
./touchupTRAW.sh
./generateSNPandGenePosfiles.sh
```
Run MatrixEQTL
```{bash}
./runMatrix-eQTL.sh
```

# prep for colocalization analysis (non-conditional)
Generate the data needed for each coloc run
```{bash}
./generateGeneSpecificCisEQTLs.sh
./generateSBCfpkms.sh
```

# Plot colocalization at key loci
```{bash}
./prep_plotColoc.sh
Rscript plotColoc.R
```

# Run colocalization (non-conditional)
Don't condition on the lead variant
```{bash}
./runColoc.sh
```

# Look further into the most colocalized signal from non-conditional coloc
```{bash}
Rscript plotVEGFBleadvariant.R
```

# double-check the effect of the VEGFB lead variant triglyerides in METSIM 10k
Run PCA on all SNPs
```{bash}
./runPLINKpca.sh
```

Generate the covariate file for the linear model
```{bash}
Rscript generateLMcovPheno.R
```

Run the linear model
```{bash}
./runPLINKlm_rs2701540_TG.sh
```

# Run colocalization analysis again (conditional)
First, create an LD matrix with pairwise correlation between SNPs 
Only make an LD matrix for SNPs that have a GWAS signal in their overlap with GWAS variants

Get the list of SNPs with a GWAS signal
```{bash}
Rscript getGWASsignalSBCs.R
```

Generate SNP position files for each gene/trait combination that's relevant
```{bash}
Rscript generateGeneSpecificSNPlists.R
```

Create the LD matrices
```{bash}
./runPLINKldmatrix.sh
```

# run coloc in conditional mode
```{bash}
./runConditionalColoc.sh
```







